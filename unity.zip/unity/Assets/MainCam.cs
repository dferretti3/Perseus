using UnityEngine;
using System.Collections;

public class MainCam : MonoBehaviour {

	// Use this for initialization
	void Start () {
	//lol
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
